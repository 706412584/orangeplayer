package com.shuyu.gsyvideoplayer;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.Surface;

import androidx.annotation.Nullable;

import com.shuyu.gsyvideoplayer.cache.CacheFactory;
import com.shuyu.gsyvideoplayer.cache.ICacheManager;
import com.shuyu.gsyvideoplayer.cast.CastCapability;
import com.shuyu.gsyvideoplayer.listener.GSYMediaPlayerListener;
import com.shuyu.gsyvideoplayer.model.GSYModel;
import com.shuyu.gsyvideoplayer.model.VideoOptionModel;
import com.shuyu.gsyvideoplayer.player.BasePlayerManager;
import com.shuyu.gsyvideoplayer.player.IPlayerInitSuccessListener;
import com.shuyu.gsyvideoplayer.player.IPlayerManager;
import com.shuyu.gsyvideoplayer.player.IjkPlayerManager;
import com.shuyu.gsyvideoplayer.player.PlayerFactory;
import com.shuyu.gsyvideoplayer.utils.Debuger;
import com.shuyu.gsyvideoplayer.utils.GSYVideoType;
import com.shuyu.gsyvideoplayer.video.base.GSYVideoViewBridge;

import java.io.BufferedInputStream;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;

import tv.danmaku.ijk.media.player.IMediaPlayer;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;
import tv.danmaku.ijk.media.player.MediaInfo;

/**
 * 基类管理器
 * GSYVideoViewBridge接口说明可以查阅GSYVideoViewBridge类
 * Created by guoshuyu on 2018/1/25.
 */

public abstract class GSYVideoBaseManager implements IMediaPlayer.OnPreparedListener, IMediaPlayer.OnCompletionListener, IMediaPlayer.OnBufferingUpdateListener, IMediaPlayer.OnSeekCompleteListener, IMediaPlayer.OnErrorListener, IMediaPlayer.OnVideoSizeChangedListener, IMediaPlayer.OnInfoListener, ICacheManager.ICacheAvailableListener, GSYVideoViewBridge {

    public static String TAG = "GSYVideoBaseManager";

    protected static final int HANDLER_PREPARE = 0;

    protected static final int HANDLER_SETDISPLAY = 1;

    protected static final int HANDLER_RELEASE = 2;

    protected static final int HANDLER_RELEASE_SURFACE = 3;

    protected static final int HANDLER_SMART_MEDIA_CODEC_FALLBACK = 4;

    protected static final int BUFFER_TIME_OUT_ERROR = -192;//外部超时错误码

    private static final int MEDIA_ERROR_IJK_PLAYER = -10000;

    protected Context context;

    protected MediaHandler mMediaHandler;
    protected Looper mLooper;

    protected Handler mainThreadHandler;

    protected WeakReference<GSYMediaPlayerListener> listener;

    protected WeakReference<GSYMediaPlayerListener> lastListener;

    protected IPlayerInitSuccessListener mPlayerInitSuccessListener;

    /**
     * 配置ijk option
     */
    protected List<VideoOptionModel> optionModelList;

    /**
     * 播放的tag，防止错位置，因为普通的url也可能重复
     */
    protected String playTag = "";

    /**
     * 播放内核管理
     */
    protected IPlayerManager playerManager;

    /**
     * 缓存管理
     */
    protected ICacheManager cacheManager;

    /**
     * 当前播放的视频宽的高
     */
    protected int currentVideoWidth = 0;

    /**
     * 当前播放的视屏的高
     */
    protected int currentVideoHeight = 0;

    /**
     * 当前视频的最后状态
     */
    protected int lastState;

    /**
     * 播放的tag，防止错位置，因为普通的url也可能重复
     */
    protected int playPosition = -22;

    /**
     * 缓冲比例
     */
    protected int bufferPoint;

    /**
     * 播放超时
     */
    protected int timeOut = 8 * 1000;

    /**
     * 是否需要静音
     */
    protected boolean needMute = false;

    /**
     * 是否需要外部超时判断
     */
    protected boolean needTimeOutOther;

    private GSYModel currentModel;

    private Surface currentSurface;

    private boolean smartMediaCodecFallbacked;

    private boolean smartMediaCodecFallbacking;

    private boolean smartMediaCodecUsingHardDecode;

    private long smartMediaCodecFallbackResumePosition;

    private IMediaPlayer smartMediaCodecFallbackSourcePlayer;

    /**
     * 删除默认所有缓存文件
     */
    public void clearAllDefaultCache(Context context) {
        clearDefaultCache(context, null, null);
    }

    /**
     * 清除缓存
     *
     * @param cacheDir 缓存目录，为空是使用默认目录
     * @param url      指定url缓存，为空时清除所有
     */
    public void clearDefaultCache(Context context, @Nullable File cacheDir, @Nullable String url) {
        if (cacheManager != null) {
            cacheManager.clearCache(context, cacheDir, url);
        } else {
            if (getCacheManager() != null) {
                getCacheManager().clearCache(context, cacheDir, url);
            }
        }
    }

    protected void init() {
        initMediaHandler();
        mainThreadHandler = new Handler(Looper.getMainLooper());
    }

    protected void initMediaHandler() {
        mMediaHandler = new MediaHandler(mLooper == null ? Looper.getMainLooper() : mLooper);
    }

    protected IPlayerManager getPlayManager() {
        return PlayerFactory.getPlayManager();
    }

    protected ICacheManager getCacheManager() {
        return CacheFactory.getCacheManager();
    }

    @Override
    public GSYMediaPlayerListener listener() {
        if (listener == null) return null;
        return listener.get();
    }

    @Override
    public GSYMediaPlayerListener lastListener() {
        if (lastListener == null) return null;
        return lastListener.get();
    }

    @Override
    public void setListener(GSYMediaPlayerListener listener) {
        if (listener == null) this.listener = null;
        else this.listener = new WeakReference<>(listener);
    }

    @Override
    public void setLastListener(GSYMediaPlayerListener lastListener) {
        if (lastListener == null) this.lastListener = null;
        else this.lastListener = new WeakReference<>(lastListener);
    }

    @Override
    public void setSpeed(float speed, boolean soundTouch) {
        if (playerManager != null) {
            playerManager.setSpeed(speed, soundTouch);
        }
    }

    @Override
    public void prepare(String url, Map<String, String> mapHeadData, boolean loop, float speed, boolean cache, File cachePath) {
        prepare(url, mapHeadData, loop, speed, cache, cachePath, null);
    }

    @Override
    public void prepare(final String url, final Map<String, String> mapHeadData, boolean loop, float speed, boolean cache, File cachePath, String overrideExtension) {
        if (TextUtils.isEmpty(url)) return;
        Message msg = new Message();
        msg.what = HANDLER_PREPARE;
        GSYModel fb = new GSYModel(url, mapHeadData, loop, speed, cache, cachePath, overrideExtension);
        msg.obj = fb;
        sendMessage(msg);
    }


    @Override
    public void prepare(final BufferedInputStream videoBufferedInputStream, final Map<String, String> mapHeadData, boolean loop, float speed, boolean cache, File cachePath) {
        prepare(videoBufferedInputStream, mapHeadData, loop, speed, cache, cachePath, null);
    }

    @Override
    public void prepare(final BufferedInputStream videoBufferedInputStream, final Map<String, String> mapHeadData, boolean loop, float speed, boolean cache, File cachePath, String overrideExtension) {
        if (videoBufferedInputStream == null) {
            return;
        }
        Message msg = new Message();
        msg.what = HANDLER_PREPARE;
        msg.obj = new GSYModel(videoBufferedInputStream, mapHeadData, loop, speed, cache, cachePath, null);
        sendMessage(msg);
    }

    @Override
    public void releaseMediaPlayer() {
        Message msg = new Message();
        msg.what = HANDLER_RELEASE;
        sendMessage(msg);
        playTag = "";
        playPosition = -22;
    }

    @Override
    public void setDisplay(Surface holder) {
        currentSurface = holder;
        Message msg = new Message();
        msg.what = HANDLER_SETDISPLAY;
        msg.obj = holder;
        showDisplay(msg);
    }

    @Override
    public void releaseSurface(Surface holder) {
        Message msg = new Message();
        msg.what = HANDLER_RELEASE_SURFACE;
        msg.obj = holder;
        sendMessage(msg);
    }

    @Override
    public void onPrepared(IMediaPlayer mp) {
        if (smartMediaCodecFallbacking) {
            try {
                if (playerManager != null) {
                    playerManager.start();
                    if (smartMediaCodecFallbackResumePosition > 0) {
                        playerManager.seekTo(smartMediaCodecFallbackResumePosition);
                    }
                }
            } catch (Exception e) {
                Debuger.printfWarning("smart mediaCodec fallback start error: " + e);
            }
            smartMediaCodecFallbacking = false;
            smartMediaCodecFallbackResumePosition = 0;
            smartMediaCodecFallbackSourcePlayer = null;
        }
        mainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                cancelTimeOutBuffer();
                if (listener() != null) {
                    listener().onPrepared();
                }
            }
        });
    }

    @Override
    public void onCompletion(IMediaPlayer mp) {
        mainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                cancelTimeOutBuffer();
                if (listener() != null) {
                    listener().onAutoCompletion();
                }
            }
        });
    }

    @Override
    public void onBufferingUpdate(IMediaPlayer mp, final int percent) {
        mainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                if (listener() != null) {
                    if (percent > bufferPoint) {
                        listener().onBufferingUpdate(percent);
                    } else {
                        listener().onBufferingUpdate(bufferPoint);
                    }
                }
            }
        });
    }

    @Override
    public void onSeekComplete(IMediaPlayer mp) {
        mainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                cancelTimeOutBuffer();
                if (listener() != null) {
                    listener().onSeekComplete();
                }
            }
        });
    }

    @Override
    public boolean onError(IMediaPlayer mp, final int what, final int extra) {
        if (trySmartMediaCodecFallback(mp, what, extra)) {
            return true;
        }
        if (smartMediaCodecFallbacking && mp == smartMediaCodecFallbackSourcePlayer) {
            return true;
        }
        mainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                cancelTimeOutBuffer();
                if (listener() != null) {
                    listener().onError(what, extra);
                }
            }
        });
        return true;
    }

    @Override
    public boolean onInfo(IMediaPlayer mp, final int what, final int extra) {
        updateSmartMediaCodecDecodeState(mp);
        mainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                if (needTimeOutOther) {
                    if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                        startTimeOutBuffer();
                    } else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END) {
                        cancelTimeOutBuffer();
                    }
                }
                if (listener() != null) {
                    listener().onInfo(what, extra);
                }
            }
        });
        return false;
    }

    @Override
    public void onVideoSizeChanged(IMediaPlayer mp, int width, int height, int sar_num, int sar_den) {
        currentVideoWidth = mp.getVideoWidth();
        currentVideoHeight = mp.getVideoHeight();
        mainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                if (listener() != null) {
                    listener().onVideoSizeChanged();
                }
            }
        });
    }

    private boolean trySmartMediaCodecFallback(IMediaPlayer mp, int what, int extra) {
        if (!shouldSmartMediaCodecFallback(mp, what, extra)) {
            return false;
        }
        long resumePosition = 0;
        try {
            if (playerManager != null) {
                resumePosition = playerManager.getCurrentPosition();
            }
        } catch (Exception e) {
            Debuger.printfWarning("smart mediaCodec fallback get position error: " + e);
        }
        smartMediaCodecFallbacked = true;
        smartMediaCodecFallbacking = true;
        smartMediaCodecFallbackSourcePlayer = mp;
        smartMediaCodecFallbackResumePosition = Math.max(0, resumePosition);

        Message msg = new Message();
        msg.what = HANDLER_SMART_MEDIA_CODEC_FALLBACK;
        msg.obj = new SmartMediaCodecFallbackData(currentModel, smartMediaCodecFallbackResumePosition);
        sendMessage(msg);
        Debuger.printfWarning("smart mediaCodec fallback to soft decode, what=" + what + ", extra=" + extra + ", position=" + smartMediaCodecFallbackResumePosition);
        return true;
    }

    private boolean shouldSmartMediaCodecFallback(IMediaPlayer mp, int what, int extra) {
        if (!GSYVideoType.isSmartMediaCodec() || !GSYVideoType.isMediaCodec()) {
            return false;
        }
        if (!(playerManager instanceof IjkPlayerManager) || !(mp instanceof IjkMediaPlayer)) {
            return false;
        }
        if (smartMediaCodecFallbacked || smartMediaCodecFallbacking) {
            return false;
        }
        if (currentModel == null || currentModel.isMediaCodecDisabled()) {
            return false;
        }
        if (currentModel.getVideoBufferedInputStream() != null) {
            return false;
        }
        return isMediaCodecUnsupportedError(what, extra);
    }

    private boolean isMediaCodecUnsupportedError(int what, int extra) {
        if (what == IMediaPlayer.MEDIA_ERROR_UNSUPPORTED || extra == IMediaPlayer.MEDIA_ERROR_UNSUPPORTED) {
            return true;
        }
        return what == MEDIA_ERROR_IJK_PLAYER && extra == IMediaPlayer.MEDIA_ERROR_UNSUPPORTED;
    }

    private void updateSmartMediaCodecDecodeState(IMediaPlayer mp) {
        if (!GSYVideoType.isSmartMediaCodec() || !(mp instanceof IjkMediaPlayer)) {
            return;
        }
        if (isMediaCodecDecoder(mp)) {
            smartMediaCodecUsingHardDecode = true;
        }
    }

    private boolean isMediaCodecDecoder(IMediaPlayer mp) {
        if (!(mp instanceof IjkMediaPlayer)) {
            return false;
        }
        try {
            IjkMediaPlayer ijkMediaPlayer = (IjkMediaPlayer) mp;
            if (ijkMediaPlayer.getVideoDecoder() == IjkMediaPlayer.FFP_PROPV_DECODER_MEDIACODEC) {
                return true;
            }
            MediaInfo mediaInfo = ijkMediaPlayer.getMediaInfo();
            return mediaInfo != null
                && mediaInfo.mVideoDecoder != null
                && mediaInfo.mVideoDecoder.toLowerCase().contains("mediacodec");
        } catch (Exception e) {
            Debuger.printfWarning("smart mediaCodec decoder check error: " + e);
            return smartMediaCodecUsingHardDecode;
        }
    }


    @Override
    public void onCacheAvailable(File cacheFile, String url, int percentsAvailable) {
        bufferPoint = percentsAvailable;
    }

    @Override
    public int getLastState() {
        return lastState;
    }

    @Override
    public void setLastState(int lastState) {
        this.lastState = lastState;
    }

    @Override
    public int getCurrentVideoWidth() {
        return currentVideoWidth;
    }

    @Override
    public int getCurrentVideoHeight() {
        return currentVideoHeight;
    }

    @Override
    public void setCurrentVideoHeight(int currentVideoHeight) {
        this.currentVideoHeight = currentVideoHeight;
    }

    @Override
    public void setCurrentVideoWidth(int currentVideoWidth) {
        this.currentVideoWidth = currentVideoWidth;
    }

    @Override
    public String getPlayTag() {
        return playTag;
    }

    @Override
    public void setPlayTag(String playTag) {
        this.playTag = playTag;
    }

    @Override
    public int getPlayPosition() {
        return playPosition;
    }

    @Override
    public void setPlayPosition(int playPosition) {
        this.playPosition = playPosition;
    }


    @Override
    public boolean isCacheFile() {
        return cacheManager != null && cacheManager.hadCached();
    }

    /**
     * 这里只是用于点击时判断是否已经缓存
     * 所以每次直接通过一个CacheManager对象判断即可
     */
    @Override
    public boolean cachePreview(Context context, File cacheDir, String url) {
        if (getCacheManager() != null) {
            return getCacheManager().cachePreview(context, cacheDir, url);
        }
        return false;
    }

    @Override
    public long getNetSpeed() {
        if (playerManager != null) {
            return playerManager.getNetSpeed();
        }
        return 0;
    }

    @Override
    public void clearCache(Context context, File cacheDir, String url) {
        clearDefaultCache(context, cacheDir, url);
    }


    @Override
    public int getBufferedPercentage() {
        if (playerManager != null) {
            return playerManager.getBufferedPercentage();
        }
        return 0;
    }

    @Override
    public void setSpeedPlaying(float speed, boolean soundTouch) {
        if (playerManager != null) {
            playerManager.setSpeedPlaying(speed, soundTouch);
        }
    }

    @Override
    public IPlayerManager getPlayer() {
        return playerManager;
    }

    /**
     * 内核层投屏能力入口（DLNA/UPnP/…）。
     * <p>返回全局单例 {@link CastCapability}。首次访问不会自动注册任何 provider。
     * DLNA 实现从 13.2.1 起位于可选的 {@code gsyvideoplayer-cast} artifact；app 显式依赖后，
     * 注册 {@code JupnpDlnaProvider} 以便按需 bind/unbind 系统服务。</p>
     */
    public CastCapability getCastCapability() {
        return CastCapability.getInstance();
    }

    @Override
    public void start() {
        if (playerManager != null) {
            playerManager.start();
        }
    }

    @Override
    public void stop() {
        if (playerManager != null) {
            playerManager.stop();
        }
    }

    @Override
    public void pause() {
        if (playerManager != null) {
            playerManager.pause();
        }
    }

    @Override
    public int getVideoWidth() {
        if (playerManager != null) {
            return playerManager.getVideoWidth();
        }
        return 0;
    }

    @Override
    public int getVideoHeight() {
        if (playerManager != null) {
            return playerManager.getVideoHeight();
        }
        return 0;
    }

    @Override
    public boolean isPlaying() {
        if (playerManager != null) {
            return playerManager.isPlaying();
        }
        return false;
    }

    @Override
    public void seekTo(long time) {
        if (playerManager != null) {
            playerManager.seekTo(time);
        }
    }

    @Override
    public long getCurrentPosition() {
        if (playerManager != null) {
            return playerManager.getCurrentPosition();
        }
        return 0;
    }

    @Override
    public long getDuration() {
        if (playerManager != null) {
            return playerManager.getDuration();
        }
        return 0;
    }

    @Override
    public int getVideoSarNum() {
        if (playerManager != null) {
            return playerManager.getVideoSarNum();
        }
        return 0;
    }

    @Override
    public int getVideoSarDen() {
        if (playerManager != null) {
            return playerManager.getVideoSarDen();
        }
        return 0;
    }

    @Override
    public int getRotateInfoFlag() {
        return IMediaPlayer.MEDIA_INFO_VIDEO_ROTATION_CHANGED;
    }


    @Override
    public boolean isSurfaceSupportLockCanvas() {
        if (playerManager != null) {
            return playerManager.isSurfaceSupportLockCanvas();
        }
        return false;
    }

    protected void sendMessage(Message message) {
        mMediaHandler.sendMessage(message);
    }

    private class MediaHandler extends Handler {

        MediaHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case HANDLER_PREPARE:
                    currentModel = (GSYModel) msg.obj;
                    resetSmartMediaCodecState();
                    initVideo(msg);
                    if (needTimeOutOther) {
                        startTimeOutBuffer();
                    }
                    break;
                case HANDLER_SETDISPLAY:
                    break;
                case HANDLER_RELEASE:
                    if (playerManager != null) {
                        playerManager.release();
                    }
                    if (cacheManager != null) {
                        cacheManager.release();
                    }
                    bufferPoint = 0;
                    setNeedMute(false);
                    cancelTimeOutBuffer();
                    currentModel = null;
                    resetSmartMediaCodecState();
                    break;
                case HANDLER_RELEASE_SURFACE:
                    releaseSurface(msg);
                    break;
                case HANDLER_SMART_MEDIA_CODEC_FALLBACK:
                    handleSmartMediaCodecFallback((SmartMediaCodecFallbackData) msg.obj);
                    break;
            }
        }

    }

    private void handleSmartMediaCodecFallback(SmartMediaCodecFallbackData fallbackData) {
        if (fallbackData == null || fallbackData.model == null || fallbackData.model != currentModel) {
            smartMediaCodecFallbacking = false;
            smartMediaCodecFallbackResumePosition = 0;
            smartMediaCodecFallbackSourcePlayer = null;
            return;
        }
        fallbackData.model.setMediaCodecDisabled(true);
        smartMediaCodecFallbackResumePosition = fallbackData.resumePosition;
        cancelTimeOutBuffer();
        if (cacheManager != null) {
            try {
                cacheManager.release();
            } catch (Exception e) {
                Debuger.printfWarning("smart mediaCodec fallback cache release error: " + e);
            }
        }
        Message msg = new Message();
        msg.what = HANDLER_PREPARE;
        msg.obj = fallbackData.model;
        initVideo(msg);
        if (needTimeOutOther) {
            startTimeOutBuffer();
        }
    }

    private void initVideo(Message msg) {
        try {
            currentModel = (GSYModel) msg.obj;
            currentVideoWidth = 0;
            currentVideoHeight = 0;

            if (playerManager != null) {
                playerManager.release();
            }
            playerManager = getPlayManager();
            cacheManager = getCacheManager();
            if (cacheManager != null) {
                cacheManager.setCacheAvailableListener(this);
            }
            if (playerManager instanceof BasePlayerManager) {
                ((BasePlayerManager) playerManager).setPlayerInitSuccessListener(mPlayerInitSuccessListener);
            }
            playerManager.initVideoPlayer(context, msg, optionModelList, cacheManager);

            setNeedMute(needMute);
            IMediaPlayer mediaPlayer = playerManager.getMediaPlayer();
            if (mediaPlayer == null) {
                notifyPrepareError();
                return;
            }
            mediaPlayer.setOnCompletionListener(this);
            mediaPlayer.setOnBufferingUpdateListener(this);
            mediaPlayer.setScreenOnWhilePlaying(true);
            mediaPlayer.setOnPreparedListener(this);
            mediaPlayer.setOnSeekCompleteListener(this);
            mediaPlayer.setOnErrorListener(this);
            mediaPlayer.setOnInfoListener(this);
            mediaPlayer.setOnVideoSizeChangedListener(this);
            if (smartMediaCodecFallbacking && currentSurface != null && currentSurface.isValid()) {
                Message displayMsg = new Message();
                displayMsg.obj = currentSurface;
                showDisplay(displayMsg);
            }
            // Surface 先于 prepare 到达的场景（如冷启动时渲染 View 早已创建）：
            // showDisplay 的 playerManager 空保护会把这枚已缓存的 surface 静默丢弃，
            // 部分内核（如 libmpv）要求 loadfile 前必须先 attach surface 且不会再有
            // 第二次 surfaceCreated 回调。这里在 prepareAsync 前主动补推一次，
            // 与上方 smartMediaCodecFallbacking 分支对称。对其它内核是幂等操作
            //（重复 setSurface 无害，且本来 surface 迟到时也会在 prepare 后再推）。
            // 独立 try-catch：个别管理器（如系统内核 idle 态 pause）抛出的异常
            // 不应中断本次 prepare。
            if (currentSurface != null && currentSurface.isValid()) {
                try {
                    Message displayMsg = new Message();
                    displayMsg.obj = currentSurface;
                    showDisplay(displayMsg);
                } catch (Exception surfaceException) {
                    surfaceException.printStackTrace();
                }
            }
            mediaPlayer.prepareAsync();

        } catch (Exception e) {
            e.printStackTrace();
            notifyPrepareError();
        }
    }

    private void notifyPrepareError() {
        if (playerManager != null) {
            try {
                playerManager.release();
            } catch (Exception releaseException) {
                releaseException.printStackTrace();
            }
        }
        if (cacheManager != null) {
            try {
                cacheManager.release();
            } catch (Exception releaseException) {
                releaseException.printStackTrace();
            }
        }
        bufferPoint = 0;
        cancelTimeOutBuffer();
        smartMediaCodecFallbacking = false;
        smartMediaCodecFallbackResumePosition = 0;
        smartMediaCodecFallbackSourcePlayer = null;
        mainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                if (listener() != null) {
                    listener().onError(IMediaPlayer.MEDIA_ERROR_UNKNOWN, IMediaPlayer.MEDIA_ERROR_UNKNOWN);
                }
            }
        });
    }

    private void resetSmartMediaCodecState() {
        smartMediaCodecFallbacked = false;
        smartMediaCodecFallbacking = false;
        smartMediaCodecUsingHardDecode = false;
        smartMediaCodecFallbackResumePosition = 0;
        smartMediaCodecFallbackSourcePlayer = null;
    }

    private static class SmartMediaCodecFallbackData {
        final GSYModel model;
        final long resumePosition;

        SmartMediaCodecFallbackData(GSYModel model, long resumePosition) {
            this.model = model;
            this.resumePosition = resumePosition;
        }
    }


    /**
     * 启动十秒的定时器进行 缓存操作
     */
    protected void startTimeOutBuffer() {
        // 启动定时
        Debuger.printfError("startTimeOutBuffer");
        mainThreadHandler.postDelayed(mTimeOutRunnable, timeOut);

    }

    /**
     * 取消 十秒的定时器进行 缓存操作
     */
    protected void cancelTimeOutBuffer() {
        Debuger.printfError("cancelTimeOutBuffer");
        // 取消定时
        if (needTimeOutOther) mainThreadHandler.removeCallbacks(mTimeOutRunnable);
    }


    private Runnable mTimeOutRunnable = new Runnable() {
        @Override
        public void run() {
            if (listener() != null) {
                Debuger.printfError("time out for error listener");
                listener().onError(BUFFER_TIME_OUT_ERROR, BUFFER_TIME_OUT_ERROR);
            }
        }
    };

    private void releaseSurface(Message msg) {
        if (msg.obj != null) {
            if (playerManager != null) {
                playerManager.releaseSurface();
            }
        }
    }

    /**
     * 后面再修改设计模式吧，现在先用着
     */
    private void showDisplay(Message msg) {
        if (playerManager != null) {
            playerManager.showDisplay(msg);
        }
    }

    public void initContext(Context context) {
        this.context = context.getApplicationContext();
    }

    /**
     * 打开raw播放支持
     *
     * @param context
     */
    public void enableRawPlay(Context context) {
        this.context = context.getApplicationContext();
    }

    public List<VideoOptionModel> getOptionModelList() {
        return optionModelList;
    }

    /**
     * 设置IJK视频的option
     */
    public void setOptionModelList(List<VideoOptionModel> optionModelList) {
        this.optionModelList = optionModelList;
    }

    public boolean isNeedMute() {
        return needMute;
    }

    /**
     * 是否需要静音
     */
    public void setNeedMute(boolean needMute) {
        this.needMute = needMute;
        if (playerManager != null) {
            playerManager.setNeedMute(needMute);
        }
    }

    public int getTimeOut() {
        return timeOut;
    }

    public boolean isNeedTimeOutOther() {
        return needTimeOutOther;
    }

    /**
     * 是否需要在buffer缓冲时，增加外部超时判断
     * <p>
     * 超时后会走onError接口，播放器通过onPlayError回调出
     * <p>
     * 错误码为 ： BUFFER_TIME_OUT_ERROR = -192
     * <p>
     * 由于onError之后执行GSYVideoPlayer的OnError，如果不想触发错误，
     * 可以重载onError，在super之前拦截处理。
     * <p>
     * public void onError(int what, int extra){
     * do you want before super and return;
     * super.onError(what, extra)
     * }
     *
     * @param timeOut          超时时间，毫秒 默认8000
     * @param needTimeOutOther 是否需要延时设置，默认关闭
     */
    public void setTimeOut(int timeOut, boolean needTimeOutOther) {
        this.timeOut = timeOut;
        this.needTimeOutOther = needTimeOutOther;
    }

    public IPlayerManager getCurPlayerManager() {
        return playerManager;
    }

    public ICacheManager getCurCacheManager() {
        return cacheManager;
    }

    public IPlayerInitSuccessListener getPlayerPreparedSuccessListener() {
        return mPlayerInitSuccessListener;
    }

    /**
     * 播放器初始化后接口
     */
    public void setPlayerInitSuccessListener(IPlayerInitSuccessListener listener) {
        this.mPlayerInitSuccessListener = listener;
    }


    public Looper getLooper() {
        return mLooper;
    }

    /// 谨慎设置
    public void setLooper(Looper mLooper) {
        this.mLooper = mLooper;
        if (mMediaHandler != null) {
            initMediaHandler();
        }
    }
}
