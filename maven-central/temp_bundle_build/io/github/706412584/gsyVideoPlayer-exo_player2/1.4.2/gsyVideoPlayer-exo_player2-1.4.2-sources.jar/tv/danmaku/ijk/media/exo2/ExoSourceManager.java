package tv.danmaku.ijk.media.exo2;


import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.Util;
import androidx.media3.database.DatabaseProvider;
import androidx.media3.database.StandaloneDatabaseProvider;
import androidx.media3.datasource.AssetDataSource;
import androidx.media3.datasource.DataSink;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.RawResourceDataSource;
import androidx.media3.datasource.cache.Cache;
import androidx.media3.datasource.cache.CacheDataSource;
import androidx.media3.datasource.cache.CacheKeyFactory;
import androidx.media3.datasource.cache.CacheSpan;
import androidx.media3.datasource.cache.ContentMetadata;
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor;
import androidx.media3.datasource.cache.SimpleCache;
import androidx.media3.datasource.rtmp.RtmpDataSource;
import androidx.media3.exoplayer.dash.DashMediaSource;
import androidx.media3.exoplayer.dash.DefaultDashChunkSource;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.rtsp.RtspMediaSource;
import androidx.media3.exoplayer.smoothstreaming.DefaultSsChunkSource;
import androidx.media3.exoplayer.smoothstreaming.SsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter;
import androidx.media3.extractor.DefaultExtractorsFactory;

import android.text.TextUtils;

import com.google.common.base.Ascii;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableSet;


/**
 * Created by guoshuyu on 2018/5/18.
 */

public class ExoSourceManager {

    private static final String TAG = "ExoSourceManager";

    public static final long DEFAULT_CACHE_MAX_SIZE = 512L * 1024L * 1024L;

    private static long sCacheMaxSize = DEFAULT_CACHE_MAX_SIZE;

    public static final int TYPE_RTMP = 14;

    private static final Map<String, CacheHolder> sCacheHolderMap = new HashMap<>();
    /**
     * 忽律Https证书校验
     *
     * @deprecated 如果需要忽略证书，请直接使用 ExoMediaSourceInterceptListener 的 getHttpDataSourceFactory
     */
    @Deprecated
    private static boolean sSkipSSLChain = false;

    private static int sHttpReadTimeout = -1;

    private static int sHttpConnectTimeout = -1;

    private static boolean isForceRtspTcp = true;

    private Context mAppContext;

    private Map<String, String> mMapHeadData;

    private String mDataSource;

    private static ExoMediaSourceInterceptListener sExoMediaSourceInterceptListener;
    private static DatabaseProvider sDatabaseProvider;

    private boolean isCached = false;
    private String mCurrentCachePath;

    public static ExoSourceManager newInstance(Context context, @Nullable Map<String, String> mapHeadData) {
        return new ExoSourceManager(context, mapHeadData);
    }

    private ExoSourceManager(Context context, Map<String, String> mapHeadData) {
        mAppContext = context.getApplicationContext();
        mMapHeadData = mapHeadData;
    }

    /**
     * @param dataSource  链接
     * @param preview     是否带上header，默认有header自动设置为true
     * @param cacheEnable 是否需要缓存
     * @param isLooping   是否循环
     * @param cacheDir    自定义缓存目录
     */
    public MediaSource getMediaSource(String dataSource, boolean preview, boolean cacheEnable, boolean isLooping, File cacheDir, @Nullable String overrideExtension) {
        isCached = false;
        MediaSource mediaSource = null;
        if (sExoMediaSourceInterceptListener != null) {
            mediaSource = sExoMediaSourceInterceptListener.getMediaSource(dataSource, preview, cacheEnable, isLooping, cacheDir);
        }
        if (mediaSource != null) {
            return mediaSource;
        }
        mDataSource = dataSource;
        Uri contentUri = Uri.parse(dataSource);
        MediaItem mediaItem = MediaItem.fromUri(contentUri);
        int contentType = inferContentType(dataSource, overrideExtension);

        String uerAgent = null;
        if (mMapHeadData != null) {
            uerAgent = mMapHeadData.get("User-Agent");
        }
        if ("android.resource".equals(contentUri.getScheme())) {
            DataSource.Factory factory = new DataSource.Factory() {
                @Override
                public DataSource createDataSource() {
                    try {
                        return new RawResourceDataSource(mAppContext);
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw e;
                    }
                }
            };
            return new ProgressiveMediaSource.Factory(factory).createMediaSource(mediaItem);

        } else if ("assets".equals(contentUri.getScheme())) {
            DataSource.Factory factory = new DataSource.Factory() {
                @Override
                public DataSource createDataSource() {
                    try {
                        return new AssetDataSource(mAppContext);
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw e;
                    }
                }
            };
            return new ProgressiveMediaSource.Factory(factory).createMediaSource(mediaItem);
        }

        switch (contentType) {
            case C.CONTENT_TYPE_SS:
                mediaSource = new SsMediaSource.Factory(new DefaultSsChunkSource.Factory(getDataSourceFactoryCache(mAppContext, cacheEnable, preview, cacheDir, uerAgent)),
                    new DefaultDataSource.Factory(mAppContext, getHttpDataSourceFactory(mAppContext, preview, uerAgent, mMapHeadData)))
                    .createMediaSource(mediaItem);
                break;

            case C.CONTENT_TYPE_RTSP:
                RtspMediaSource.Factory rtspFactory = new RtspMediaSource.Factory();
                if (uerAgent != null) {
                    rtspFactory.setUserAgent(uerAgent);
                }
                if (sHttpConnectTimeout > 0) {
                    rtspFactory.setTimeoutMs(sHttpConnectTimeout);
                }
                rtspFactory.setForceUseRtpTcp(isForceRtspTcp);
                mediaSource = rtspFactory.createMediaSource(mediaItem);
                break;

            case C.CONTENT_TYPE_DASH:
                mediaSource = new DashMediaSource.Factory(new DefaultDashChunkSource.Factory(getDataSourceFactoryCache(mAppContext, cacheEnable, preview, cacheDir, uerAgent)),
                    new DefaultDataSource.Factory(mAppContext, getHttpDataSourceFactory(mAppContext, preview, uerAgent, mMapHeadData)))
                    .createMediaSource(mediaItem);
                break;
            case C.CONTENT_TYPE_HLS:
                mediaSource = new HlsMediaSource.Factory(getDataSourceFactoryCache(mAppContext, cacheEnable, preview, cacheDir, uerAgent)).setAllowChunklessPreparation(true).createMediaSource(mediaItem);
                break;
            case TYPE_RTMP:
                RtmpDataSource.Factory rtmpDataSourceFactory = new RtmpDataSource.Factory();
                mediaSource = new ProgressiveMediaSource.Factory(rtmpDataSourceFactory, new DefaultExtractorsFactory()).createMediaSource(mediaItem);
                break;
            case C.CONTENT_TYPE_OTHER:
            default:
                mediaSource = new ProgressiveMediaSource.Factory(getDataSourceFactoryCache(mAppContext, cacheEnable, preview, cacheDir, uerAgent), new DefaultExtractorsFactory()).createMediaSource(mediaItem);
                break;
        }
        return mediaSource;
    }


    /**
     * 设置ExoPlayer 的 MediaSource 创建拦截
     */
    public static void setExoMediaSourceInterceptListener(ExoMediaSourceInterceptListener exoMediaSourceInterceptListener) {
        sExoMediaSourceInterceptListener = exoMediaSourceInterceptListener;
    }

    public static void resetExoMediaSourceInterceptListener() {
        sExoMediaSourceInterceptListener = null;
    }

    public static ExoMediaSourceInterceptListener getExoMediaSourceInterceptListener() {
        return sExoMediaSourceInterceptListener;
    }

    /**
     * Returns the max bytes used by new Exo {@link SimpleCache} instances.
     */
    public static synchronized long getCacheMaxSize() {
        return sCacheMaxSize;
    }

    /**
     * Sets the max bytes used by new Exo {@link SimpleCache} instances.
     * <p>
     * This must be called before any Exo cache instance is acquired. Existing
     * Media3 cache evictors cannot be resized after the cache is created.
     */
    public static synchronized void setCacheMaxSize(long cacheMaxSize) {
        if (cacheMaxSize <= 0) {
            throw new IllegalArgumentException("cacheMaxSize must be greater than 0");
        }
        if (!sCacheHolderMap.isEmpty()) {
            throw new IllegalStateException("Exo cache max size must be set before cache is created");
        }
        sCacheMaxSize = cacheMaxSize;
    }

    /**
     * Restores the default Exo cache max size.
     */
    public static synchronized void resetCacheMaxSize() {
        if (!sCacheHolderMap.isEmpty()) {
            throw new IllegalStateException("Exo cache max size must be reset before cache is created");
        }
        sCacheMaxSize = DEFAULT_CACHE_MAX_SIZE;
    }


    @SuppressLint("WrongConstant")
    @C.ContentType
    public static int inferContentType(String fileName, @Nullable String overrideExtension) {
        fileName = Ascii.toLowerCase(fileName);
        if (fileName.startsWith("rtmp:")) {
            return TYPE_RTMP;
        } else {
            return inferContentType(Uri.parse(fileName), overrideExtension);
        }
    }

    @C.ContentType
    public static int inferContentType(Uri uri, @Nullable String overrideExtension) {
        return TextUtils.isEmpty(overrideExtension) ? Util.inferContentType(uri)
            : Util.inferContentTypeForExtension(overrideExtension);
    }

    /**
     * 本地缓存目录
     */
    public static synchronized Cache getCacheSingleInstance(Context context, File cacheDir) {
        return getOrCreateCacheHolder(context, cacheDir, false, false).cache;
    }

    public static synchronized Cache acquireCacheSingleInstance(Context context, File cacheDir) {
        return getOrCreateCacheHolder(context, cacheDir, true, false).cache;
    }

    public static synchronized Cache acquireCacheSingleInstance(Context context, File cacheDir, boolean fallbackWhenLocked) {
        CacheHolder cacheHolder = getOrCreateCacheHolder(context, cacheDir, true, fallbackWhenLocked);
        return cacheHolder != null ? cacheHolder.cache : null;
    }

    public static synchronized void releaseCacheSingleInstance(Context context, File cacheDir) {
        releaseCacheHolder(buildCachePath(context, cacheDir));
    }

    public static String getCachePath(Context context, File cacheDir) {
        return buildCachePath(context, cacheDir);
    }

    public void release() {
        isCached = false;
        if (!TextUtils.isEmpty(mCurrentCachePath)) {
            releaseCacheHolder(mCurrentCachePath);
            mCurrentCachePath = null;
        }
    }

    /**
     * Cache需要release之后才能clear
     */
    public static void clearCache(Context context, File cacheDir, String url) {
        Cache cache = null;
        try {
            cache = acquireCacheSingleInstance(context, cacheDir, true);
            if (cache == null) {
                return;
            }
            if (!TextUtils.isEmpty(url)) {
                removeCache(cache, url);
            } else {
                for (String key : cache.getKeys()) {
                    removeCache(cache, key);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cache != null) {
                releaseCacheSingleInstance(context, cacheDir);
            }
        }
    }


    public static void removeCache(Cache cache, String url) {
        NavigableSet<CacheSpan> cachedSpans = cache.getCachedSpans(buildCacheKey(url));
        for (CacheSpan cachedSpan : cachedSpans) {
            try {
                cache.removeSpan(cachedSpan);
            } catch (Exception e) {
                // Do nothing.
            }
        }
    }

    public static String buildCacheKey(String url) {
        DataSpec dataSpec = new DataSpec(Uri.parse(url));
        String key = CacheKeyFactory.DEFAULT.buildCacheKey(dataSpec);
        return key;
    }

    public static boolean cachePreView(Context context, File cacheDir, String url) {
        Cache cache = null;
        try {
            cache = acquireCacheSingleInstance(context, cacheDir, true);
            return cache != null && resolveCacheState(cache, url);
        } finally {
            if (cache != null) {
                releaseCacheSingleInstance(context, cacheDir);
            }
        }
    }

    public boolean hadCached() {
        return isCached;
    }

    /**
     * 忽律Https证书校验
     *
     * @deprecated 如果需要忽略证书，请直接使用 ExoMediaSourceInterceptListener 的 getHttpDataSourceFactory
     */
    @Deprecated
    public static boolean isSkipSSLChain() {
        return sSkipSSLChain;
    }

    /**
     * 设置https忽略证书
     *
     * @param skipSSLChain true时是hulve
     * @deprecated 如果需要忽略证书，请直接使用 ExoMediaSourceInterceptListener 的 getHttpDataSourceFactory
     */
    @Deprecated
    public static void setSkipSSLChain(boolean skipSSLChain) {
        sSkipSSLChain = skipSSLChain;
    }


    public static int getHttpReadTimeout() {
        return sHttpReadTimeout;
    }

    /**
     * 如果设置小于 0 就使用默认 8000 MILLIS
     */
    public static void setHttpReadTimeout(int httpReadTimeout) {
        ExoSourceManager.sHttpReadTimeout = httpReadTimeout;
    }

    public static int getHttpConnectTimeout() {
        return sHttpConnectTimeout;
    }

    /**
     * 如果设置小于 0 就使用默认 8000 MILLIS
     */
    public static void setHttpConnectTimeout(int httpConnectTimeout) {
        ExoSourceManager.sHttpConnectTimeout = httpConnectTimeout;
    }

    public static DatabaseProvider getDatabaseProvider() {
        return sDatabaseProvider;
    }

    public static void setDatabaseProvider(DatabaseProvider databaseProvider) {
        ExoSourceManager.sDatabaseProvider = databaseProvider;
    }

    public static boolean isForceRtspTcp() {
        return isForceRtspTcp;
    }

    public static void setForceRtspTcp(boolean isForceRtspTcp) {
        ExoSourceManager.isForceRtspTcp = isForceRtspTcp;
    }

    /**
     * 获取SourceFactory，是否带Cache
     */
    private DataSource.Factory getDataSourceFactoryCache(Context context, boolean cacheEnable, boolean preview, File cacheDir, String uerAgent) {
        if (cacheEnable) {
            CacheHolder cacheHolder = acquireCacheHolder(context, cacheDir);
            if (cacheHolder != null && cacheHolder.cache != null) {
                Cache cache = cacheHolder.cache;
                DataSink.Factory cacheSinkFactory = null;
                if (sExoMediaSourceInterceptListener != null) {
                    cacheSinkFactory = sExoMediaSourceInterceptListener.cacheWriteDataSinkFactory(cacheHolder.cachePath, mDataSource);
                }
                isCached = resolveCacheState(cache, mDataSource);
                CacheDataSource.Factory factory = new CacheDataSource.Factory();
                CacheDataSource.Factory dataSourceFactory = factory.setCache(cache)
                    .setCacheReadDataSourceFactory(getDataSourceFactory(context, preview, uerAgent, mMapHeadData))
                    .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
                    .setUpstreamDataSourceFactory(getHttpDataSourceFactory(context, preview, uerAgent, mMapHeadData));
                if (sExoMediaSourceInterceptListener != null && cacheSinkFactory != null) {
                    dataSourceFactory.setCacheWriteDataSinkFactory(cacheSinkFactory);
                }
                return dataSourceFactory;
            }
        }
        return getDataSourceFactory(context, preview, uerAgent, mMapHeadData);
    }

    private synchronized CacheHolder acquireCacheHolder(Context context, File cacheDir) {
        String cachePath = buildCachePath(context, cacheDir);
        if (!TextUtils.isEmpty(mCurrentCachePath) && mCurrentCachePath.equals(cachePath)) {
            return getOrCreateCacheHolder(context, cacheDir, false, true);
        }
        if (!TextUtils.isEmpty(mCurrentCachePath) && !mCurrentCachePath.equals(cachePath)) {
            releaseCacheHolder(mCurrentCachePath);
            mCurrentCachePath = null;
        }
        CacheHolder cacheHolder = getOrCreateCacheHolder(context, cacheDir, true, true);
        if (cacheHolder == null) {
            return null;
        }
        mCurrentCachePath = cacheHolder.cachePath;
        return cacheHolder;
    }

    private static synchronized CacheHolder getOrCreateCacheHolder(Context context, File cacheDir, boolean incrementRef, boolean fallbackWhenLocked) {
        String cachePath = buildCachePath(context, cacheDir);
        CacheHolder cacheHolder = sCacheHolderMap.get(cachePath);
        if (cacheHolder == null) {
            File cacheFolder = new File(cachePath);
            if (SimpleCache.isCacheFolderLocked(cacheFolder)) {
                if (fallbackWhenLocked) {
                    Log.w(TAG, "Exo cache folder is locked, fallback without cache: " + cachePath);
                    return null;
                }
                throw new IllegalStateException("Exo cache folder is locked: " + cachePath);
            }
            Cache cache = new SimpleCache(cacheFolder, new LeastRecentlyUsedCacheEvictor(sCacheMaxSize),
                sDatabaseProvider != null ? sDatabaseProvider : new StandaloneDatabaseProvider(context));
            cacheHolder = new CacheHolder(cachePath, cache);
            sCacheHolderMap.put(cachePath, cacheHolder);
        }
        if (incrementRef) {
            cacheHolder.refCount++;
        }
        return cacheHolder;
    }

    private static synchronized void releaseCacheHolder(String cachePath) {
        CacheHolder cacheHolder = sCacheHolderMap.get(cachePath);
        if (cacheHolder == null) {
            return;
        }
        if (cacheHolder.refCount > 0) {
            cacheHolder.refCount--;
        }
        if (cacheHolder.refCount == 0) {
            try {
                cacheHolder.cache.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
            sCacheHolderMap.remove(cachePath);
        }
    }

    private static String buildCachePath(Context context, File cacheDir) {
        String dirs = context.getCacheDir().getAbsolutePath();
        if (cacheDir != null) {
            dirs = cacheDir.getAbsolutePath();
        }
        return dirs + File.separator + "exo";
    }

    private static final class CacheHolder {
        private final String cachePath;
        private final Cache cache;
        private int refCount;

        private CacheHolder(String cachePath, Cache cache) {
            this.cachePath = cachePath;
            this.cache = cache;
        }
    }


    /**
     * 获取SourceFactory
     */
    public static DataSource.Factory getDataSourceFactory(Context context, boolean preview, String uerAgent, Map<String, String> mapHeadData) {
        DefaultDataSource.Factory factory = new DefaultDataSource.Factory(context, getHttpDataSourceFactory(context, preview, uerAgent, mapHeadData));
        if (preview) {
            factory.setTransferListener(new DefaultBandwidthMeter.Builder(context).build());
        }
        return factory;
    }

    public static DataSource.Factory getHttpDataSourceFactory(Context context, boolean preview, String uerAgent, Map<String, String> mapHeadData) {
        if (uerAgent == null) {
            uerAgent = Util.getUserAgent(context, TAG);
        }
        int connectTimeout = DefaultHttpDataSource.DEFAULT_CONNECT_TIMEOUT_MILLIS;
        int readTimeout = DefaultHttpDataSource.DEFAULT_READ_TIMEOUT_MILLIS;
        if (sHttpConnectTimeout > 0) {
            connectTimeout = sHttpConnectTimeout;
        }
        if (sHttpReadTimeout > 0) {
            readTimeout = sHttpReadTimeout;
        }
        boolean allowCrossProtocolRedirects = false;
        if (mapHeadData != null && mapHeadData.size() > 0) {
            allowCrossProtocolRedirects = "true".equals(mapHeadData.get("allowCrossProtocolRedirects"));
        }
        DataSource.Factory dataSourceFactory = null;
        if (sExoMediaSourceInterceptListener != null) {
            dataSourceFactory = sExoMediaSourceInterceptListener.
                getHttpDataSourceFactory(uerAgent, preview ? null :
                        new DefaultBandwidthMeter.Builder(context.getApplicationContext()).build(),
                    connectTimeout, readTimeout, mapHeadData, allowCrossProtocolRedirects);
        }
        if (dataSourceFactory == null) {
            dataSourceFactory = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(allowCrossProtocolRedirects)
                .setConnectTimeoutMs(connectTimeout)
                .setReadTimeoutMs(readTimeout)
                .setTransferListener(preview ? null : new DefaultBandwidthMeter.Builder(context.getApplicationContext()).build());
            if (mapHeadData != null && mapHeadData.size() > 0) {
                ((DefaultHttpDataSource.Factory) dataSourceFactory).setDefaultRequestProperties(mapHeadData);
            }
        }
        return dataSourceFactory;
    }

    /**
     * 根据缓存块判断是否缓存成功
     */
    private static boolean resolveCacheState(Cache cache, String url) {
        boolean isCache = true;
        if (!TextUtils.isEmpty(url)) {
            String key = buildCacheKey(url);
            if (!TextUtils.isEmpty(key)) {
                NavigableSet<CacheSpan> cachedSpans = cache.getCachedSpans(key);
                if (cachedSpans.size() == 0) {
                    isCache = false;
                } else {
                    long contentLength = cache.getContentMetadata(key).get(ContentMetadata.KEY_CONTENT_LENGTH, C.LENGTH_UNSET);
                    long currentLength = 0;
                    for (CacheSpan cachedSpan : cachedSpans) {
                        currentLength += cache.getCachedLength(key, cachedSpan.position, cachedSpan.length);
                    }
                    isCache = currentLength >= contentLength;
                }
            } else {
                isCache = false;
            }
        }
        return isCache;
    }
}
