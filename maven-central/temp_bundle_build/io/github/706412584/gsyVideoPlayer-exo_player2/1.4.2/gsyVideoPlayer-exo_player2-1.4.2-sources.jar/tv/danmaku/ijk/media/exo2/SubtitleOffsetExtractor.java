package tv.danmaku.ijk.media.exo2;

import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.ExtractorInput;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.ForwardingExtractorOutput;
import androidx.media3.extractor.ForwardingTrackOutput;
import androidx.media3.extractor.PositionHolder;
import androidx.media3.extractor.SeekMap;
import androidx.media3.extractor.SeekPoint;
import androidx.media3.extractor.TrackOutput;

import java.io.IOException;

final class SubtitleOffsetExtractor implements Extractor {

    private final Extractor delegate;
    private final long offsetUs;

    SubtitleOffsetExtractor(Extractor delegate, long offsetUs) {
        this.delegate = delegate;
        this.offsetUs = offsetUs;
    }

    @Override
    public boolean sniff(ExtractorInput input) throws IOException {
        return delegate.sniff(input);
    }

    @Override
    public void init(ExtractorOutput output) {
        delegate.init(new ForwardingExtractorOutput(output) {
            @Override
            public TrackOutput track(int id, int type) {
                return new ForwardingTrackOutput(super.track(id, type)) {
                    @Override
                    public void durationUs(long durationUs) {
                        super.durationUs(shiftBounded(durationUs));
                    }

                    @Override
                    public void sampleMetadata(long timeUs, int flags, int size, int offset,
                            CryptoData cryptoData) {
                        super.sampleMetadata(shift(timeUs), flags, size, offset, cryptoData);
                    }
                };
            }

            @Override
            public void seekMap(SeekMap seekMap) {
                super.seekMap(new SeekMap() {
                    @Override
                    public boolean isSeekable() {
                        return seekMap.isSeekable();
                    }

                    @Override
                    public long getDurationUs() {
                        return shiftBounded(seekMap.getDurationUs());
                    }

                    @Override
                    public SeekPoints getSeekPoints(long timeUs) {
                        SeekPoints points = seekMap.getSeekPoints(unshift(timeUs));
                        return new SeekPoints(shift(points.first), shift(points.second));
                    }
                });
            }
        });
    }

    @Override
    public int read(ExtractorInput input, PositionHolder seekPosition) throws IOException {
        return delegate.read(input, seekPosition);
    }

    @Override
    public void seek(long position, long timeUs) {
        delegate.seek(position, unshift(timeUs));
    }

    @Override
    public void release() {
        delegate.release();
    }

    private long shift(long timeUs) {
        return timeUs == androidx.media3.common.C.TIME_UNSET ? timeUs : timeUs + offsetUs;
    }

    private long shiftBounded(long timeUs) {
        return timeUs == androidx.media3.common.C.TIME_UNSET
                ? timeUs
                : Math.max(0, shift(timeUs));
    }

    private long unshift(long timeUs) {
        return Math.max(0, timeUs - offsetUs);
    }

    private SeekPoint shift(SeekPoint point) {
        return new SeekPoint(Math.max(0, shift(point.timeUs)), point.position);
    }
}
